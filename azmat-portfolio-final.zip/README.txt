# Azmat Ullah Portfolio

GitHub: https://github.com/azmat784
LinkedIn: https://www.linkedin.com/in/azmat-ullah-682188394

The social buttons are already connected to these profiles.
The LinkedIn URL was normalized from the link you sent by removing the extra trailing ".linkdn".
